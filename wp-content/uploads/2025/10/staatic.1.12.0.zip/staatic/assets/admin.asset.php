<?php

namespace Staatic\Vendor;

return array(
    'dependencies' => array('react', 'wp-api-fetch', 'wp-components', 'wp-dom-ready', 'wp-element', 'wp-i18n'),
    'version' => 'ada5665f2d8c9c1bda18'
);
