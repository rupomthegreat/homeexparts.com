<?php

declare(strict_types=1);

namespace Staatic\WordPress\Publication\Task;

interface RestartableTaskInterface extends TaskInterface
{
}
