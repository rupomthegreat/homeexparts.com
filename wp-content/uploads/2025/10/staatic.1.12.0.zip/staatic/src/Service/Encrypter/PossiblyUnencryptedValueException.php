<?php

declare(strict_types=1);

namespace Staatic\WordPress\Service\Encrypter;

class PossiblyUnencryptedValueException extends InvalidValueException
{
}
