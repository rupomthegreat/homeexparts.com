<?php

namespace Staatic\WordPress\Module\Deployer\SftpDeployer;

use RuntimeException;

class SftpLoginException extends RuntimeException
{
}
